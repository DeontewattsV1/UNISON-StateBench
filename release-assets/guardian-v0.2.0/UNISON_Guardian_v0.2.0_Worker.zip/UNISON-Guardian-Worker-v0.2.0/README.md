# UNISON Guardian prebuilt Worker

This package contains the synthetic public sandbox. Public model requests are disabled.
The full source ZIP contains the repository; run development commands from guardian/.

Review deployment-record.json, wrangler.jsonc, LICENSE, NOTICE and dependency notices.
The configuration uses the existing unison-guardian Worker name. Choose the intended
Cloudflare account before any deployment; hosting can incur usage charges.

For a local preview, use the source checkout and its pinned Wrangler dependency.
To deploy these prebuilt bytes with Wrangler 4.155.0, run from this directory:

    npx wrangler@4.155.0 deploy

Preserve the v1 Durable Object migration. Existing sessions remain operator-controlled
SQLite checkpoints, not authenticated people, signatures or an immutable external ledger.
All protected actions change synthetic counters only. No model key is required.
